
cd $( dirname "${BASH_SOURCE[0]}" )
rm -rf __pycache__
cd ../
echo `pwd`

rm spark_lib/spark_lib.zip
zip -r spark_lib.zip spark_lib/
mv spark_lib.zip spark_lib/spark_lib.zip

