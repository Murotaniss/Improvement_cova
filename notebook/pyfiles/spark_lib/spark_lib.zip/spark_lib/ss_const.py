
EXCLUDE_UUID = [
         'idfa:',
         'imei:',
         'idfa:00000000-0000-0000-0000-000000000000',
         'anid:00000000-0000-0000-0000-000000000000',
         'imei:0',
         'imei:00000000',
         'imei:000000000000000',
         'YYYYYYYYYYYYYYYYYYYYYYYY',
         'XXXXXXXXXXXXXXXXXXXXXXXX' ]


